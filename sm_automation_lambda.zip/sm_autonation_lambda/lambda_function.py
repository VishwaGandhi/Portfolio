import boto3
import time
from botocore.vendored import requests
from websocket import websocket

def lambda_handler(event, context):
    
    sm_client = boto3.client('sagemaker')
    # Provide sagemaker instance name here
    notebook_instance_name = 'sagemaker-notebook-instance'
    
    timeCounter = time.time()
    
    # Changes notebook instance state to 'InService' if not adn waits till changed for defined period
    if((sm_client.describe_notebook_instance(NotebookInstanceName = notebook_instance_name))['NotebookInstanceStatus'] != 'InService'):
        sm_client.start_notebook_instance(NotebookInstanceName=notebook_instance_name)
        while(((sm_client.describe_notebook_instance(NotebookInstanceName = notebook_instance_name))['NotebookInstanceStatus'] != 'InService') and ((time.time() - timeCounter) < 240) ):
            time.sleep(5)
    
    # Terminates function in case of delay/failure to change the notebook instance state to 'InService'    
    if((sm_client.describe_notebook_instance(NotebookInstanceName = notebook_instance_name))['NotebookInstanceStatus'] != 'InService'):
        print("Operation timed out, instance not started")
        return 0
       
    url = sm_client.create_presigned_notebook_instance_url(NotebookInstanceName=notebook_instance_name)['AuthorizedUrl']
    url_tokens = url.split('/')
    http_proto = url_tokens[0]
    http_hn = url_tokens[2].split('?')[0].split('#')[0]

    s = requests.Session()
    r = s.get(url)
    cookies = "; ".join(key + "=" + value for key, value in s.cookies.items())


    ws = websocket.create_connection(
        "wss://{}/terminals/websocket/1".format(http_hn),
        cookie=cookies,
        host=http_hn,
        origin=http_proto + "//" + http_hn
    )    

    # Replace Notebook .ipynb file location here
    ws.send("""[ "stdin", "jupyter nbconvert --execute --to notebook --inplace /home/ec2-user/SageMaker/jupyter-notebook-filename.ipynb --ExecutePreprocessor.kernel_name=python3 --ExecutePreprocessor.timeout=1500\\r" ]""" )

    time.sleep(1)

    ws.close()

    return None